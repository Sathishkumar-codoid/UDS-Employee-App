import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:uds_employee/Network/APIMethods.dart';
import 'package:uds_employee/Utils/AppAlertController.dart';

import '../Allnavigations/AllBlocDirectory.dart';

abstract class LeaveEvent extends Equatable {
  @override
  // TODO: implement props
  List<Object?> get props => [];
}

class LeaveTypeListEvent extends LeaveEvent {
  BuildContext context;

  LeaveTypeListEvent(this.context);
}

class LeaveStatusEvent extends LeaveEvent {
  String userId;
  String status;
  BuildContext context;

  LeaveStatusEvent(this.context, this.userId, this.status);
}

class LeaveApplyEvent extends LeaveEvent {
  var payload;
  BuildContext context;

  LeaveApplyEvent(this.payload, this.context);
}

abstract class LeaveState extends Equatable {
  @override
  // TODO: implement props
  List<Object?> get props => [];
}

class LeaveTypeListLoadingState extends LeaveState {}

class LeaveTypeListSuccessState extends LeaveState {
  var data;

  LeaveTypeListSuccessState(this.data);
}

class LeaveTypeListErrorState extends LeaveState {
  String error;

  LeaveTypeListErrorState(this.error);
}

class LeaveStatusLoadingState extends LeaveState {}

class LeaveStatusSuccessState extends LeaveState {
  var data;

  LeaveStatusSuccessState(this.data);
}

class LeaveStatusErrorState extends LeaveState {
  String error;

  LeaveStatusErrorState(this.error);
}

class LeaveApplyLoadingState extends LeaveState {}

class LeaveApplySuccessState extends LeaveState {
  var data;

  LeaveApplySuccessState(this.data);
}

class LeaveApplyErrorState extends LeaveState {
  String error;

  LeaveApplyErrorState(this.error);
}

class LeaveBloc extends Bloc<LeaveEvent, LeaveState> {
  LeaveBloc() : super(LeaveTypeListLoadingState());
  @override
  Stream<LeaveState> mapEventToState(LeaveEvent event) async* {
    yield LeaveTypeListLoadingState();
    if (event is LeaveTypeListEvent) {
      yield await _getLeaveTypeList(event);
    }

    if (event is LeaveStatusEvent) {
      yield await _getLeaveStaus(event);
    }

    if (event is LeaveApplyEvent) {
      yield await _applyLeave(event);
    }
  }

  Future<LeaveState> _getLeaveTypeList(LeaveTypeListEvent event) async {
    var state;

    await APIManager().leavetypeList(successBlock: (data) {
      state = LeaveTypeListLoadingState();
      if (data['status']['code'] == 200) {
        state = LeaveTypeListSuccessState(data['data']);
      }
    }, failureBlock: (exception) {
      state = LeaveTypeListErrorState(exception.toString());
      AppAlertController()
          .showAlert(message: exception.toString(), inContext: event.context);
    });

    print(state);
    return state;
  }

  Future<LeaveState> _getLeaveStaus(LeaveStatusEvent event) async {
    var state;
    await APIManager().leaveStatus(
        userId: event.userId,
        status: event.status,
        successBlock: (data) {
          state = LeaveStatusLoadingState();
          state = LeaveStatusSuccessState(data);
        },
        failureBlock: (exception) {
          state = LeaveStatusErrorState(exception.toString());

          AppAlertController().showAlert(
              message: exception.toString(), inContext: event.context!);
        });
    return state;
  }

  Future<LeaveState> _applyLeave(LeaveApplyEvent event) async {
    var state;
    await APIManager().applyleave(
        payload: event.payload,
        successBlock: (data) {
          state = LeaveApplyLoadingState();

          state = LeaveApplySuccessState(data);
        },
        failureBlock: (exception) {
          state = LeaveApplyErrorState(exception.toString());
          AppAlertController().showAlert(
              message: exception.toString(), inContext: event.context!);
        });
    return state;
  }
}
