class APIUrlManager{
static const baseURL='http://122.186.126.218:8031';
// http://122.186.126.218:8031
// static const baseURL='http://122.186.126.218:8030';
static const PhoneNumberVerifyUrl='$baseURL/employeeapp/otp/send/';
static const otpVerifyUrl='$baseURL/employeeapp/otp/verify/';
static const employeOfferLetter='$baseURL/employeeapp/offerletter/';
static const getCalenderUrl='$baseURL/employeeapp/attendance/';
static const getShiftTiming='$baseURL/employeeapp/shifttimeing/';
static const attendanceUpdate='$baseURL/employeeapp/attendance/';
static const checkinStatus='$baseURL/employeeapp/inout/';
static const leaveTypes='$baseURL/management/leavetype/get/';
static const applyLeave='$baseURL/management/leaves/';



}